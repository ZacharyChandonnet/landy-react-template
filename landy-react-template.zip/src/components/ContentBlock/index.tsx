import { Row, Col } from "antd";
import { Fade } from "react-awesome-reveal";
import { withTranslation } from "react-i18next";

import { ContentBlockProps } from "./types";
import { Button } from "../../common/Button";
import { SvgIcon } from "../../common/SvgIcon";
import {
  ContentSection,
  Content,
  ContentWrapper,
  ServiceWrapper,
  MinTitle,
  MinPara,
  StyledRow,
  ButtonWrapper,
} from "./styles";

const ContentBlock = ({
  icon,
  title,
  content,
  section,
  button,
  t,
  id,
  direction,
}: ContentBlockProps) => {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id) as HTMLDivElement;
    element.scrollIntoView({
      behavior: "smooth",
    });
  };

  const renderTitle = (value: string) => {
    const parts = value.split(/(services|action)/i);

    return parts.map((part, index) =>
      /^(services|action)$/i.test(part) ? (
        <span key={`${part}-${index}`} style={{ color: "var(--secondary)" }}>
          {part}
        </span>
      ) : (
        part
      )
    );
  };

  return (
    <ContentSection>
      <Fade direction={direction} triggerOnce>
        <StyledRow
          justify="space-between"
          align="middle"
          id={id}
          direction={direction}
        >
          <Col lg={11} md={11} sm={12} xs={24}>
            <SvgIcon src={icon} width="100%" height="100%" />
          </Col>
          <Col lg={11} md={11} sm={11} xs={24}>
            <ContentWrapper>
              <h6>{renderTitle(t(title))}</h6>
              <Content>{t(content)}</Content>
              {section && section.length > 0 && (
                <ServiceWrapper>
                  <Row gutter={[16, 24]} justify="space-between">
                    {typeof section === "object" &&
                      section.map(
                        (
                          item: {
                            title: string;
                            content: string;
                            icon: string;
                          },
                          id: number
                        ) => {
                          return (
                            <Col key={id} xs={24} sm={12}>
                              <SvgIcon
                                src={item.icon}
                                width="60px"
                                height="60px"
                              />
                              <MinTitle>{t(item.title)}</MinTitle>
                              <MinPara>{t(item.content)}</MinPara>
                            </Col>
                          );
                        }
                      )}
                  </Row>
                </ServiceWrapper>
              )}
              {direction === "right" && button && button.length > 0 && (
                <ButtonWrapper>
                  {button.map((item, id) =>
                    item.url ? (
                      <a
                        key={id}
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Button color={item.color} className="pdfCtaButton">
                          {t(item.title)}
                        </Button>
                      </a>
                    ) : (
                          <Button
                            key={id}
                            color={item.color}
                            onClick={() => scrollTo(item.target || "about")}
                          >
                            {t(item.title)}
                          </Button>
                    )
                  )}
                </ButtonWrapper>
              )}
            </ContentWrapper>
          </Col>
        </StyledRow>
      </Fade>
    </ContentSection>
  );
};

export default withTranslation()(ContentBlock);
